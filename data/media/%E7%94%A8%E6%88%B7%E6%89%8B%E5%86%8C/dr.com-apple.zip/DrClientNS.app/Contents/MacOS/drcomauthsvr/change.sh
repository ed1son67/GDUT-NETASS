#!/bin/sh

FULLPATH=$1
echo $FULLPATH
chmod -R 4777 "$FULLPATH"
chown -R root:admin "$FULLPATH"

echo "YES"
